const ADD_TODO_BUTTON_ID = 'add-todo-button'
const TODO_TO_ADD_INPUT_FIELD_ID = 'todo-to-add'
const TODO_PAGE_TEMPLATE_ID = 'todos'
const INFO_PAGE_TEMPLATE_ID = 'info'
const TODO_DETAIL_PAGE_TEMPLATE_ID = 'todo-detail'

const todos = [
    { label: 'Commencer ce TP', checked: true, createdBy: 'foo', createdOn: '2019-01-01', description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed leo erat, iaculis eu nibh a, cursus semper libero. Proin at.'},
    { label: 'Finir ce TP', checked: false, createdBy: 'foo', createdOn: '2019-01-01', description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed leo erat, iaculis eu nibh a, cursus semper libero. Proin at.'},
    { label: 'Comprendre quelles problématiques résolvent les frameworks comme Vue.js, Angular et React', checked: false, createdBy: 'foo', createdOn: '2019-01-01', description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed leo erat, iaculis eu nibh a, cursus semper libero. Proin at.'},
    { label: 'Expérimenter ces problématiques', checked: false, createdBy: 'foo', createdOn: '2019-01-01', description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed leo erat, iaculis eu nibh a, cursus semper libero. Proin at.'},
    { label: 'Obtenir un aperçu des problématiques principales du développement/de l\'architecture frontend', checked: false, createdBy: 'foo', createdOn: '2019-01-01', description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed leo erat, iaculis eu nibh a, cursus semper libero. Proin at.'},
    { label: 'Ecrire une première application frontend avec Vue.js', checked: false, createdBy: 'foo', createdOn: '2019-01-01', description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed leo erat, iaculis eu nibh a, cursus semper libero. Proin at.'},
    { label: 'Prendre du recul sur son utilisation et sur le développement frontend en général', checked: false, createdBy: 'foo', createdOn: '2019-01-01', description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed leo erat, iaculis eu nibh a, cursus semper libero. Proin at.'}
]

window.onload = () => router()
window.onpopstate = () => router()

function router() {
    if ('content' in document.createElement('template')) {
        routeUser()
    } else {
        alert('ERROR: this website is not compatible with your browser. Please download a modern one.')
    }
}

function routeUser() {
    const userRequestedRoute = window.location.hash.startsWith('#')
      ? window.location.hash.substring(1)
      : window.location.hash

    if (userRequestedRoute === '' || userRequestedRoute === '/home') {
        displayTodoListPage()
    } else if (userRequestedRoute === '/info') {
        displayInfoPage()
    } else if (userRequestedRoute.startsWith('/todo-detail')) {
        const todoId = userRequestedRoute.substring('/todo-detail/'.length)
        displayTodoDetailsPage(todoId)
    } else {
        display404()
    }
}

function emptyDiv(divElement) {
    while (divElement.hasChildNodes()) {   
        divElement.removeChild(divElement.firstChild);
    }
}

function getCleanedAppElement() {
    const app = document.getElementById('app')
    emptyDiv(app)
    return app
}

function displayTodoListPage() {
    emptyAppAndDisplayTemplateFromId(TODO_PAGE_TEMPLATE_ID)

    document.getElementById(ADD_TODO_BUTTON_ID).addEventListener('click', addTodoAndRenderThemAll(todos))
    insertTodosIntoDocument(todos)
}

function displayInfoPage() {
    emptyAppAndDisplayTemplateFromId(INFO_PAGE_TEMPLATE_ID)
}

function displayTodoDetailsPage(todoId) {
    const app = getCleanedAppElement()
    if (todos[todoId]) {
        app.appendChild(createTodoDetailFromTemplate(todos, todoId))
    } else {
        display404()
    }
}

function display404() {
    const app = getCleanedAppElement()
    const element = document.createElement('p')
    element.textContent = '404 - Page not found.'
    app.appendChild(element)
}

function emptyAppAndDisplayTemplateFromId(id) {
    const template = document.getElementById(id)
    const clone = document.importNode(template.content, true)

    const app = getCleanedAppElement()
    app.appendChild(clone)
}

function insertTodosIntoDocument(todos) {
    const todoList = document.getElementById('todo-list')
    emptyDiv(todoList)
    todos.forEach((todo, index) => todoList.appendChild(
        createTodoFromTemplate(todos, index, todo.label, todo.checked)
    ))
}

function createTodoFromTemplate(todos, index, label, checked) {
    const template = document.getElementById('todo-el')
    const clone = document.importNode(template.content, true)

    const todoId = 'todo-el-' + index

    const inputElement = clone.querySelector('input')
    inputElement.id = todoId
    inputElement.checked = checked
    inputElement.addEventListener('change', updateCheckedValueOfTask(todos, index))
    
    const labelElement = clone.querySelector('[data-target="todo-label"]')
    labelElement.textContent = label

    const removeButton = clone.querySelector('.todo-remove-button')
    removeButton.addEventListener('click', removeTask(todos, index))

    const detailButton = clone.querySelector('.todo-detail-button')
    detailButton.href = '#/todo-detail/' + index

    return clone
}

function createTodoDetailFromTemplate(todos, index) {
    const template = document.getElementById(TODO_DETAIL_PAGE_TEMPLATE_ID)
    const clone = document.importNode(template.content, true)
    const task = todos[index]

    clone.querySelector('[data-target="task-title"]').textContent = task.label
    clone.querySelector('[data-target="task-created-by"]').textContent = task.createdBy
    clone.querySelector('[data-target="task-created-on"]').textContent = task.createdOn
    clone.querySelector('[data-target="task-description"]').textContent = task.description

    const todoDoneButton = clone.querySelector('.todo-done-button')
    const todoNotDoneButton = clone.querySelector('.todo-not-done-button')
    if (task.checked) {
        todoNotDoneButton.addEventListener('click', () => changeTodoCheckedStateAndReloadTodoDetailPage(todos, index, false))
        todoDoneButton.style.display = 'none'
    } else {
        todoDoneButton.addEventListener('click', () => changeTodoCheckedStateAndReloadTodoDetailPage(todos, index, true))
        todoNotDoneButton.style.display = 'none'
    }

    return clone
}

function changeTodoCheckedStateAndReloadTodoDetailPage(todos, index, value) {
    todos[index].checked = value
    displayTodoDetailsPage(index)   
}

function updateCheckedValueOfTask(todos, index) {
    return (event) => {
        todos[index].checked = event.target.checked
        insertTodosIntoDocument(todos)
    }
}

function removeTask(todos, index) {
    return (event) => {
        todos.splice(index, 1)
        insertTodosIntoDocument(todos)
    }
}

function addTodoAndRenderThemAll(todos) {
    return (clickOnSubmitButtonEvent) => {
        const newTodoInputEl = document.getElementById(TODO_TO_ADD_INPUT_FIELD_ID)
        const userEnteredTodo = newTodoInputEl.value
        if (userEnteredTodo !== "") {
            todos.push({ label: userEnteredTodo, checked: false })
            newTodoInputEl.value = ''
            insertTodosIntoDocument(todos)
        }
    }
}
